from flask import Flask, render_template, url_for, request, flash

from logging import DEBUG

app = Flask(__name__)
app.logger.setLevel(DEBUG)
app.config['SECRET_KEY'] = 'thisissecretkey'

@app.route('/')
@app.route('/index')
def welcome():
    return render_template("index.html")


@app.route('/add', methods=['GET', 'POST'])
def add():
    if request.method == 'POST':
        flash('Stored bookmark')
        return render_template("index.html")

    return render_template("add.html")



if __name__ == "__main__":
    app.run(debug=True)
